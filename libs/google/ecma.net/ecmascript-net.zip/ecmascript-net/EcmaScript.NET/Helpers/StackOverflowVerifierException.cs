using System;
using System.Collections.Generic;
using System.Text;

namespace EcmaScript.NET.Helpers
{
    class StackOverflowVerifierException : ApplicationException
    {
    }
}
